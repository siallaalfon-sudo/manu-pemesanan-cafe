// ===== TOGGLE MENU MOBILE =====
const menuBtn = document.getElementById("menuBtn");
const navMenu = document.getElementById("navMenu");

if(menuBtn && navMenu){
  menuBtn.addEventListener("click", () => {
    if(navMenu.style.display === "flex"){
      navMenu.style.display = "none";
    } else {
      navMenu.style.display = "flex";
    }
  });
}

// ===== VALIDASI FORM =====
const form = document.getElementById("contactForm");
const msg = document.getElementById("msg");

if(form && msg){
  form.addEventListener("submit", function(e) {
    e.preventDefault();

    const name = document.getElementById("name")?.value.trim();
    const email = document.getElementById("email")?.value.trim();
    const message = document.getElementById("message")?.value.trim();

    if (!name || !email || !message) {
      msg.textContent = "Semua field wajib diisi!";
      msg.style.color = "red";
    } 
    else if (!email.includes("@")) {
      msg.textContent = "Format email tidak valid!";
      msg.style.color = "red";
    } 
    else {
      msg.textContent = "Pesan berhasil dikirim!";
      msg.style.color = "green";
      form.reset();
    }
  });
}
